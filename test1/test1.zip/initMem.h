// Projet: Oxymetre
// Auteurs: Axel AUBRY - Pierre PICARD
// Date de creation: 27/02/2016

#ifndef INIT_MEM_H
#define INIT_MEM_H

// Includes.
#include "define.h"

float** initMem(int x,int y);

// Sources codes
#endif
