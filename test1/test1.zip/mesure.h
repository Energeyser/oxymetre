#include "define.h"

oxy mesureTest(char* filename);
oxy mesure(absorp myAbsorp, float* mem_calcul, oxy myOxy, int* pointeursurZero, int* rang,float* maxacr, float* minacr, float* maxacir, float* minacir);
	
