
#include "define.h"


absorp firTest(char* fileName);
absorp fir(absorp myAbsorp, float** buffer);
