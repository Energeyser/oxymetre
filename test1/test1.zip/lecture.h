#include "define.h"

absorp lecture(FILE* fichier, int* etat);
