#include "define.h"


absorp iirTest(char* filename);
absorp iir(absorp myAbsorp, float** mem_iir);