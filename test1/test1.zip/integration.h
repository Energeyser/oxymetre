#include "define.h"

void integrationTest(char* fileName);
void finMem(float** tab, int x);
