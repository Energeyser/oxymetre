#ifndef MESURES_H
#define MESURES_H

#include "../main.h"


void Mesure(float tab_histo[2][5000], int DCr, int DCir, int* spo2, int* fcard);

#endif
