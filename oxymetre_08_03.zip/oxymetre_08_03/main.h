// Projet: FlyOverBoxes
// Author: Travers Steven : steven.travers@isen.fr
// Creation date: 08/12/2013
// Modification date: 08/12/2013
// Role: .

#ifndef MAIN_H
#define MAIN_H
// Includes.
#include "Affichage/affichage.h"
#include "Filtrage/filtrage.h"
#include "Lecture/lecture.h"
#include "Mesures/mesures.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


// Sources codes
#endif
